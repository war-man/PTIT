package com.example.quizapp.Service;

public interface CallBackData{
    void onReceiveData(String data) throws Exception;
}
