package com.example.son.gdghack.models;

/**
 * Created by nttungPC on 11/18/2017.
 */

public class User {
    public String username;
    public String Id;
    public static User user;

    public User(String username, String id) {
        this.username = username;
        Id = id;
    }
}
