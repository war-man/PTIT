package com.example.listviewfruit;

public class Fruit {
   public String Ten;
   public String MoTa;
   public Integer Hinh;

    public Fruit(String ten, String moTa, Integer hinh) {
        Ten = ten;
        MoTa = moTa;
        Hinh = hinh;
    }
}
