# PTIT-Internship-2019-CW
Intership - 2019
Goal :
1. Know Android basic
2. Process in work
