package com.example.ptitquiz.Model;

public class LapLich {
    public String gio,noidung;

    public LapLich(String gio, String noidung) {
        this.gio = gio;
        this.noidung = noidung;

    }


    public String getGio() {
        return gio;
    }

    public void setGio(String gio) {
        this.gio = gio;
    }

    public String getNoidung() {
        return noidung;
    }

    public void setNoidung(String noidung) {
        this.noidung = noidung;
    }

}
