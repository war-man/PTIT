package com.example.ptitquiz.Model;

public class Rank {
    private String username;

    public Rank() {
    }

    public Rank(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
