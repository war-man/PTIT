package ptit.wayne.com.ptitinfor;

public class Constant {

    // API face detection

/*
Endpoint: https://westcentralus.api.cognitive.microsoft.com/face/v1.0
Key 1: acfa5df0da6c4effb03297986f7d3bfc
Key 2: f5d6cf36c4604130807a185cdd6bd153
 */

    // http://127.0.0.1:8080/student/update?id=b14dccn096&tgi=abcxyz123&tpi=defghi345

    public static String API_ENDPOINT = "https://westcentralus.api.cognitive.microsoft.com/face/v1.0";
    public static String API_KEY = "e6d743fef63249578b9387426e909732";
    public static final String API_HOST_GROUP = "https://westcentralus.api.cognitive.microsoft.com/face/v1.0/persongroups/";

    // API Cloud
    public static String CLOUD_NAME = "9eceaa5bd6514b5186b664a568994cc8";
    public static String API_CLOUDINARY = "YRw-WxhXPb4go0g9vEk0MXY1NSg";
    public static String API_KEY_CLOUDINARY = "555153991388382";

    public static final String ABSENT ="Vắng mặt";
    public static final String PRESENT = "Có mặt";

    public static String PERSON_GROUP_ID = "";

    public static String URL_IMAGE = "https://res.cloudinary.com/daikk6zhp/image/upload/v1540635014/FaceGroup/b13dcat023/1.png";

    public static String PNG = " .png";

    public static final int PICK_IMAGE = 200;
    public static final int REQUEST_CAPTURE_IMAGE = 100;

    public static int INDEX = 0;



}
