package com.loiclude.PtitQuiz.model;

public class HistoryDTO {

	    private Integer idMonhoc;

	    private Integer soccer;
	    
	    private Integer idProfileUser;
	    
	    private String nameLesson;
	    
	    private String maSv;

		public Integer getIdMonhoc() {
			return idMonhoc;
		}

		public void setIdMonhoc(Integer idMonhoc) {
			this.idMonhoc = idMonhoc;
		}

		public Integer getSoccer() {
			return soccer;
		}

		public void setSoccer(Integer soccer) {
			this.soccer = soccer;
		}

		public Integer getIdProfileUser() {
			return idProfileUser;
		}

		public void setIdProfileUser(Integer idProfileUser) {
			this.idProfileUser = idProfileUser;
		}

		public String getNameLesson() {
			return nameLesson;
		}

		public void setNameLesson(String nameLesson) {
			this.nameLesson = nameLesson;
		}

		public String getMaSv() {
			return maSv;
		}

		public void setMaSv(String maSv) {
			this.maSv = maSv;
		}
	    
	    
}
