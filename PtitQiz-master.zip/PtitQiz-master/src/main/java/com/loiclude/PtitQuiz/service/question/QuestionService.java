package com.loiclude.PtitQuiz.service.question;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loiclude.PtitQuiz.model.CauHoi;
import com.loiclude.PtitQuiz.model.MonHoc;
import com.loiclude.PtitQuiz.model.Target;
import com.loiclude.PtitQuiz.model.TargetDTO;
import com.loiclude.PtitQuiz.model.UserProfile;
import com.loiclude.PtitQuiz.repository.CauHoiRepository;
import com.loiclude.PtitQuiz.repository.MonHocRepository;
import com.loiclude.PtitQuiz.repository.TargetRepository;
import com.loiclude.PtitQuiz.repository.UserProfileRepository;

@Service
public class QuestionService {
	
	
}
