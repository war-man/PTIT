package com.loiclude.PtitQuiz.service.answer;

import org.springframework.stereotype.Service;

@Service
public class AnswerService {
}
