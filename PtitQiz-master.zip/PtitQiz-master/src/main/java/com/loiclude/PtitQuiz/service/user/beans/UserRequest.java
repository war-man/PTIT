package com.loiclude.PtitQuiz.service.user.beans;

public class UserRequest {
    private String ma;

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }
}
