package com.example.lovermoneyptit.utils;

public interface GroupType {
    public static final int LOAN = 1;
    public static final int CASH_IN = 2;
    public static final int CASH_OUT = 3;
}
